#!/bin/bash
# LogiFlow NAS 실행 스크립트

echo "🚀 LogiFlow 시작 중..."

# 포트 7000이 사용 중인지 확인하고 종료
PID=$(lsof -ti:7000 2>/dev/null)
if [ ! -z "$PID" ]; then
    echo "⚠️  포트 7000이 사용 중입니다. 기존 프로세스를 종료합니다..."
    kill -9 $PID
    sleep 2
fi

# 가상환경이 있으면 활성화
if [ -d "venv" ]; then
    source venv/bin/activate
    echo "✅ 가상환경 활성화"
fi

# 의존성 설치 확인
if [ ! -f ".deps_installed" ]; then
    echo "📦 의존성 설치 중..."
    
    # NAS용 requirements (mariadb 제외)
    if [ -f "requirements.txt" ]; then
        grep -v "mariadb" requirements.txt > requirements_nas.txt
        pip install -r requirements_nas.txt
    else
        # 필수 패키지만 설치
        pip install Flask Flask-SQLAlchemy Flask-Cors PyMySQL bcrypt gunicorn python-dotenv
    fi
    
    touch .deps_installed
    echo "✅ 의존성 설치 완료"
fi

# 환경 설정 파일 확인
if [ ! -f ".env" ]; then
    echo "⚙️  환경 설정 파일 생성 중..."
    cat > .env << 'EOF'
FLASK_ENV=production
FLASK_DEBUG=False
PORT=7000

# 데이터베이스 설정
DB_HOST=192.168.0.109
DB_PORT=3306
DB_NAME=trade_naver_cupang
DB_USER=root
DB_PASSWORD=your_password_here

# 보안 설정
SECRET_KEY=logiflow-secret-key-change-this
EOF
    echo "✅ .env 파일이 생성되었습니다."
    echo "⚠️  .env 파일에서 DB_PASSWORD를 실제 비밀번호로 변경해주세요!"
fi

# 데이터베이스 초기화 (첫 실행시 또는 --init-db 옵션)
if [ "$1" = "--init-db" ] || [ ! -f ".db_initialized" ]; then
    echo "🗄️  데이터베이스 초기화 중..."
    if [ -f "database/init_db.py" ]; then
        python database/init_db.py
        touch .db_initialized
        echo "✅ 데이터베이스 초기화 완료"
    else
        echo "⚠️  database/init_db.py를 찾을 수 없습니다."
    fi
fi

# 애플리케이션 시작
echo "🌐 LogiFlow 시작 중... (포트 7000)"
echo "🔗 접속 주소: http://192.168.0.109:7000"
echo "👤 관리자 계정: admin / admin123"
echo ""
echo "종료하려면 Ctrl+C를 누르세요."

# wsgi.py가 있으면 사용, 없으면 app.py 사용
if [ -f "wsgi.py" ]; then
    python wsgi.py
elif [ -f "app.py" ]; then
    python app.py
else
    echo "❌ 실행할 Python 파일을 찾을 수 없습니다."
    exit 1
fi