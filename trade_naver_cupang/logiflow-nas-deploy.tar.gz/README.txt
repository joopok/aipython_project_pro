LogiFlow NAS 배포 패키지
=======================

🚀 빠른 시작 가이드

1. 압축 해제
   tar -xzf logiflow-nas-deploy.tar.gz
   cd logiflow-nas-deploy

2. 설치 실행
   ./install.sh

3. 환경 설정
   nano .env
   (DB_PASSWORD를 실제 비밀번호로 변경)

4. 서비스 시작
   ./start.sh --init-db

5. 웹 접속
   http://192.168.0.109:7000

📋 관리자 계정
   ID: admin
   PW: admin123

🛠️ 관리 명령어
   시작: ./start.sh
   종료: ./stop.sh
   재시작: ./stop.sh && ./start.sh

🔧 설정 파일
   .env - 환경 설정
   
📁 주요 디렉토리
   app/ - 애플리케이션 코드
   database/ - 데이터베이스 스크립트
   static/ - 정적 파일 (CSS, JS)
   templates/ - HTML 템플릿

⚠️ 주의사항
   - .env 파일의 DB_PASSWORD를 반드시 변경하세요
   - 포트 7000이 사용 중이면 자동으로 기존 프로세스를 종료합니다
   - 데이터베이스 연결 설정을 확인하세요

❓ 문제 해결
   1. 포트 충돌: ./stop.sh 실행 후 재시작
   2. 권한 오류: chmod +x *.sh 실행
   3. 의존성 오류: pip install -r requirements.txt 실행