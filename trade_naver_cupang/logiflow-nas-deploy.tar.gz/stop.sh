#!/bin/bash
# LogiFlow 종료 스크립트

echo "🛑 LogiFlow 종료 중..."

# 포트 7000에서 실행 중인 프로세스 찾아서 종료
PID=$(lsof -ti:7000 2>/dev/null)
if [ ! -z "$PID" ]; then
    kill -9 $PID
    echo "✅ LogiFlow 프로세스 종료됨 (PID: $PID)"
else
    echo "⚠️  실행 중인 LogiFlow 프로세스를 찾을 수 없습니다."
fi

# Python 프로세스 강제 종료 (wsgi.py 또는 app.py)
pkill -f "python wsgi.py" 2>/dev/null
pkill -f "python app.py" 2>/dev/null

echo "🏁 종료 완료"