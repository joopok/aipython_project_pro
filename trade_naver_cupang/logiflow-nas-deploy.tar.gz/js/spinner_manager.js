// 공통 스피너 관리자 - 개선된 버전
// 모든 페이지에서 공통으로 사용할 수 있는 스피너 시스템

class SpinnerManager {
    constructor() {
        this.activeSpinners = new Map();
        this.globalSpinner = null;
        this.apiCallTracker = new Map();
        this.customCompletionConditions = new Set();
        this.progressCallbacks = new Map();
        this.statusUpdateCallbacks = new Map();
        this.minDisplayTime = 3000; // 최소 3초 표시
        this.maxDisplayTime = 30000; // 최대 30초
        
        this.setupAPIInterceptors();
        this.setupGlobalEventListeners();
    }

    showGlobal(options = {}) {
        const config = {
            message: '페이지를 불러오는 중...',
            type: 'spin',
            showProgress: true,
            maxTime: this.maxDisplayTime,
            autoComplete: true,
            ...options
        };

        if (this.globalSpinner && this.globalSpinner.isActive) {
            return this.globalSpinner.id;
        }

        const spinnerId = this.generateId();
        this.globalSpinner = {
            id: spinnerId,
            isActive: true,
            config: config,
            startTime: Date.now(),
            element: null,
            progress: 0,
            status: '초기화 중...'
        };

        this.createSpinnerElement(this.globalSpinner);
        this.startProgressSimulation(spinnerId);

        // 최대 시간 후 강제 종료
        setTimeout(() => {
            this.hide(spinnerId);
        }, config.maxTime);

        if (config.autoComplete) {
            this.setupAutoComplete(spinnerId);
        }

        return spinnerId;
    }

    // 특정 컨텍스트용 스피너 (API 호출, 데이터 로딩 등)
    show(context, options = {}) {
        const config = {
            message: '처리 중...',
            type: 'spin',
            showProgress: false,
            minTime: 1000,
            maxTime: 15000,
            autoComplete: false,
            ...options
        };

        const spinnerId = this.generateId();
        const spinner = {
            id: spinnerId,
            context: context,
            isActive: true,
            config: config,
            startTime: Date.now(),
            element: null,
            progress: 0,
            status: config.message
        };

        this.activeSpinners.set(spinnerId, spinner);
        
        // 글로벌 스피너가 없으면 엘리먼트 생성
        if (!this.globalSpinner || !this.globalSpinner.isActive) {
            this.createSpinnerElement(spinner);
        } else {
            // 글로벌 스피너가 있으면 메시지 업데이트
            this.updateSpinnerContent(this.globalSpinner, config.message, config.type);
        }

        // 최소 시간 보장
        setTimeout(() => {
            if (this.activeSpinners.has(spinnerId)) {
                spinner.canHide = true;
            }
        }, config.minTime);

        // 최대 시간 후 강제 종료
        setTimeout(() => {
            this.hide(spinnerId);
        }, config.maxTime);

        return spinnerId;
    }

    // 스피너 숨기기
    hide(spinnerId) {
        let spinner = null;

        if (this.globalSpinner && this.globalSpinner.id === spinnerId) {
            spinner = this.globalSpinner;
            this.hideSpinnerElement(spinner);
            this.globalSpinner = null;
        } else if (this.activeSpinners.has(spinnerId)) {
            spinner = this.activeSpinners.get(spinnerId);
            this.activeSpinners.delete(spinnerId);

            if (this.activeSpinners.size === 0 && (!this.globalSpinner || !this.globalSpinner.isActive)) {
                this.hideSpinnerElement(spinner);
            }
        }
    }

    // 모든 스피너 숨기기
    hideAll() {
        if (this.globalSpinner) {
            this.hideSpinnerElement(this.globalSpinner);
            this.globalSpinner = null;
        }
        
        this.activeSpinners.forEach(spinner => {
            this.hideSpinnerElement(spinner);
        });
        this.activeSpinners.clear();
        
        this.enableInteractions();
    }

    // 진행률 업데이트
    setProgress(spinnerId, progress, status = null) {
        const spinner = this.getSpinner(spinnerId);
        if (!spinner) return;

        spinner.progress = Math.max(0, Math.min(100, progress));
        if (status) spinner.status = status;

        this.updateProgress(spinner);
        
        // 진행률 콜백 실행
        const callback = this.progressCallbacks.get(spinnerId);
        if (callback) callback(progress, status);
    }

    // 상태 메시지 업데이트
    setStatus(spinnerId, status) {
        const spinner = this.getSpinner(spinnerId);
        if (!spinner) return;

        spinner.status = status;
        this.updateStatus(spinner);
        
        // 상태 콜백 실행
        const callback = this.statusUpdateCallbacks.get(spinnerId);
        if (callback) callback(status);
    }

    // API 호출 추적 시작
    trackApiCall(url, method = 'GET') {
        const callId = this.generateId();
        this.apiCallTracker.set(callId, {
            url: url,
            method: method,
            startTime: Date.now(),
            completed: false
        });
        return callId;
    }

    // API 호출 완료 마킹
    completeApiCall(callId) {
        if (this.apiCallTracker.has(callId)) {
            const call = this.apiCallTracker.get(callId);
            call.completed = true;
            call.endTime = Date.now();
        }
    }

    // 사용자 정의 완료 조건 추가
    addCompletionCondition(condition) {
        if (typeof condition === 'function') {
            this.customCompletionConditions.add(condition);
        }
    }

    // 완료 조건 제거
    removeCompletionCondition(condition) {
        this.customCompletionConditions.delete(condition);
    }

    // 진행률 콜백 등록
    onProgress(spinnerId, callback) {
        this.progressCallbacks.set(spinnerId, callback);
    }

    // 상태 업데이트 콜백 등록
    onStatusUpdate(spinnerId, callback) {
        this.statusUpdateCallbacks.set(spinnerId, callback);
    }

    // 스피너 엘리먼트 생성
    createSpinnerElement(spinner) {
        console.log("[Debug] 1. createSpinnerElement 시작");
        const mainContent = document.getElementById('mainContent');
        if (!mainContent) {
            console.error("[Debug] 1a. #mainContent 요소를 찾을 수 없습니다. 스피너를 생성할 수 없습니다.");
            return;
        }
        console.log("[Debug] 1b. #mainContent 찾음:", mainContent);

        // 기존 스피너 제거
        const existingLoader = mainContent.querySelector('.main-content-loader');
        if (existingLoader) {
            console.log("[Debug] 1c. 기존 스피너 제거");
            existingLoader.remove();
        }

        const loaderElement = document.createElement('div');
        loaderElement.className = `main-content-loader spinner-type-${spinner.config.type}`;
        
        // 강제 스타일 적용 (디버깅용)
        loaderElement.style.cssText = `
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: 100% !important;
            display: flex !important;
            opacity: 1 !important;
            z-index: 99999 !important;
            background-color: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(5px);
        `;

        loaderElement.innerHTML = `
            <div class="spinner-container">
                ${this.getSpinnerHTML(spinner.config.type)}
                <div class="main-content-loader-text">${spinner.config.message}</div>
                ${spinner.config.showProgress ? this.getProgressHTML() : ''}
                <div class="loader-status">${spinner.status}</div>
            </div>
        `;

        mainContent.appendChild(loaderElement);
        spinner.element = loaderElement;
        console.log("[Debug] 1d. 새로운 스피너 엘리먼트를 #mainContent에 추가했습니다.", loaderElement);
    }

    // 스피너 HTML 생성
    getSpinnerHTML(type) {
        switch (type) {
            case 'dots':
                return `
                    <div class="main-content-spinner">
                        <div class="spinner-dots">
                            <div class="spinner-dot"></div>
                            <div class="spinner-dot"></div>
                            <div class="spinner-dot"></div>
                        </div>
                    </div>
                `;
            case 'pulse':
                return '<div class="main-content-spinner"></div>';
            default: // 'spin'
                return '<div class="main-content-spinner"></div>';
        }
    }

    // 진행률 HTML 생성
    getProgressHTML() {
        return `
            <div class="progress-container">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 0%"></div>
                </div>
                <div class="progress-text">0%</div>
            </div>
        `;
    }

    // 스피너 컨텐츠 업데이트
    updateSpinnerContent(spinner, message, type) {
        if (!spinner.element) return;

        const messageEl = spinner.element.querySelector('.main-content-loader-text');
        if (messageEl) messageEl.textContent = message;

        if (type && type !== spinner.config.type) {
            spinner.config.type = type;
            const spinnerEl = spinner.element.querySelector('.main-content-spinner');
            if (spinnerEl) {
                spinnerEl.outerHTML = this.getSpinnerHTML(type);
            }
        }
    }

    // 진행률 업데이트
    updateProgress(spinner) {
        if (!spinner.element) return;

        const progressFill = spinner.element.querySelector('.progress-fill');
        const progressText = spinner.element.querySelector('.progress-text');

        if (progressFill) {
            progressFill.style.width = `${spinner.progress}%`;
        }
        if (progressText) {
            progressText.textContent = `${Math.round(spinner.progress)}%`;
        }
    }

    // 상태 업데이트
    updateStatus(spinner) {
        if (!spinner.element) return;

        const statusEl = spinner.element.querySelector('.loader-status');
        if (statusEl) {
            statusEl.textContent = spinner.status;
        }
    }

    // 스피너 엘리먼트 숨기기
    hideSpinnerElement(spinner) {
        if (!spinner.element) return;

        spinner.element.classList.add('hidden');
        
        setTimeout(() => {
            if (spinner.element && spinner.element.parentNode) {
                spinner.element.parentNode.removeChild(spinner.element);
            }
        }, 300);
    }

    // 진행률 시뮬레이션 시작
    startProgressSimulation(spinnerId) {
        const spinner = this.getSpinner(spinnerId);
        if (!spinner || !spinner.config.showProgress) return;

        let progress = 0;
        const interval = setInterval(() => {
            if (!this.getSpinner(spinnerId)) {
                clearInterval(interval);
                return;
            }

            // 진행률 증가 (점점 느려지는 패턴)
            const remaining = 95 - progress;
            progress += remaining * 0.1;
            
            if (progress >= 95) {
                clearInterval(interval);
                this.setProgress(spinnerId, 95, '완료 확인 중...');
            } else {
                const status = this.getProgressStatus(progress);
                this.setProgress(spinnerId, progress, status);
            }
        }, 200);
    }

    // 진행률에 따른 상태 메시지
    getProgressStatus(progress) {
        if (progress < 20) return '연결 중...';
        if (progress < 40) return '데이터 요청 중...';
        if (progress < 60) return '데이터 처리 중...';
        if (progress < 80) return '화면 준비 중...';
        if (progress < 95) return '마무리 중...';
        return '완료 확인 중...';
    }

    // 자동 완료 설정
    setupAutoComplete(spinnerId) {
        const spinner = this.getSpinner(spinnerId);
        if (!spinner) return;

        const checkCompletion = () => {
            if (!this.getSpinner(spinnerId)) return;

            const conditions = [
                this.checkPageDataLoaded(),
                this.checkApiCallsCompleted(),
                this.checkCustomConditions()
            ];

            if (conditions.every(condition => condition)) {
                this.setProgress(spinnerId, 100, '완료!');
                // 로딩 완료 후 3초 대기
                setTimeout(() => {
                    this.hide(spinnerId);
                }, 3000);
            } else {
                setTimeout(checkCompletion, 500); // 0.5초마다 재확인
            }
        };

        // 최초 확인은 약간의 딜레이 후 시작
        setTimeout(checkCompletion, 500);
    }

    // 페이지 데이터 로딩 완료 확인
    checkPageDataLoaded() {
        // 로딩 스피너가 없는지 확인
        const loadingSpinners = document.querySelectorAll('.loading-spinner');
        if (loadingSpinners.length > 0) return false;

        // 테이블 데이터 또는 빈 메시지가 있는지 확인
        const tableBody = document.querySelector('#ordersTableBody, .excel-table tbody');
        const emptyMessage = document.querySelector('#emptyMessage');
        
        if (tableBody) {
            const hasData = tableBody.children.length > 0;
            const hasEmptyMessage = emptyMessage && emptyMessage.style.display !== 'none';
            return hasData || hasEmptyMessage;
        }

        // 기본 컨텐츠가 있는지 확인
        const content = document.querySelector('.content, .page-header');
        return !!content;
    }

    // API 호출 완료 확인
    checkApiCallsCompleted() {
        return Array.from(this.apiCallTracker.values()).every(call => call.completed);
    }

    // 사용자 정의 조건 확인
    checkCustomConditions() {
        return Array.from(this.customCompletionConditions).every(condition => {
            try {
                return condition();
            } catch (e) {
                console.warn('Custom completion condition error:', e);
                return true;
            }
        });
    }

    // API 인터셉터 설정
    setupAPIInterceptors() {
        const originalFetch = window.fetch;
        
        window.fetch = async (...args) => {
            const callId = this.trackApiCall(args[0], args[1]?.method || 'GET');
            
            try {
                const response = await originalFetch(...args);
                this.completeApiCall(callId);
                return response;
            } catch (error) {
                this.completeApiCall(callId);
                throw error;
            }
        };

        // XMLHttpRequest 인터셉터
        const originalXHROpen = XMLHttpRequest.prototype.open;
        const originalXHRSend = XMLHttpRequest.prototype.send;
        
        XMLHttpRequest.prototype.open = function(method, url, ...args) {
            this._callId = window.spinnerManager.trackApiCall(url, method);
            return originalXHROpen.call(this, method, url, ...args);
        };

        XMLHttpRequest.prototype.send = function(...args) {
            this.addEventListener('loadend', () => {
                if (this._callId) {
                    window.spinnerManager.completeApiCall(this._callId);
                }
            });
            return originalXHRSend.call(this, ...args);
        };
    }

    // 글로벌 이벤트 리스너 설정
    setupGlobalEventListeners() {
        // 페이지 언로드 시 모든 스피너 정리
        window.addEventListener('beforeunload', () => {
            this.hideAll();
        });

        // 에러 발생 시 스피너 숨기기
        window.addEventListener('error', () => {
            setTimeout(() => this.hideAll(), 1000);
        });
    }

    // 상호작용 비활성화
    disableInteractions() {
        const elements = document.querySelectorAll('button, input, select, textarea, a:not(.sidebar a)');
        elements.forEach(el => {
            if (!el.disabled && !el.classList.contains('spinner-disabled')) {
                el.disabled = true;
                el.classList.add('spinner-disabled');
            }
        });
    }

    // 상호작용 활성화
    enableInteractions() {
        const elements = document.querySelectorAll('.spinner-disabled');
        elements.forEach(el => {
            el.disabled = false;
            el.classList.remove('spinner-disabled');
        });
    }

    // 유틸리티 메서드들
    generateId() {
        return 'spinner_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    getSpinner(spinnerId) {
        if (this.globalSpinner && this.globalSpinner.id === spinnerId) {
            return this.globalSpinner;
        }
        return this.activeSpinners.get(spinnerId);
    }

    checkAutoComplete(spinnerId) {
        if (!this.getSpinner(spinnerId)) return;
        
        const conditions = [
            this.checkPageDataLoaded(),
            this.checkApiCallsCompleted(),
            this.checkCustomConditions()
        ];

        if (conditions.every(condition => condition)) {
            this.setProgress(spinnerId, 100, '완료!');
            setTimeout(() => this.hide(spinnerId), 500);
        }
    }
}

// 전역 스피너 매니저 인스턴스 생성
window.spinnerManager = new SpinnerManager();

// 편의 함수들 (기존 코드와의 호환성을 위해)
window.showSpinner = (message, options) => window.spinnerManager.showGlobal({ message, ...options });
window.hideSpinner = (spinnerId) => window.spinnerManager.hide(spinnerId);
window.showDataSpinner = (context, message, options) => window.spinnerManager.show(context, { message, ...options });

// 기존 mainContentLoader와의 호환성
if (!window.mainContentLoader) {
    window.mainContentLoader = {
        show: (message) => window.spinnerManager.showGlobal({ message }),
        hide: () => window.spinnerManager.hideAll(),
        isActive: false
    };
}