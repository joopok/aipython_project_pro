#!/bin/bash
# LogiFlow 설치 스크립트

echo "🎯 LogiFlow 설치 스크립트"
echo "========================="

# 실행 권한 부여
chmod +x start.sh stop.sh

echo "✅ 실행 권한 부여 완료"

# .env 파일 생성 (없는 경우만)
if [ ! -f ".env" ]; then
    echo "⚙️  환경 설정 파일 생성 중..."
    cat > .env << 'EOF'
FLASK_ENV=production
FLASK_DEBUG=False
PORT=7000

# 데이터베이스 설정
DB_HOST=192.168.0.109
DB_PORT=3306
DB_NAME=trade_naver_cupang
DB_USER=root
DB_PASSWORD=your_password_here

# 보안 설정
SECRET_KEY=logiflow-secret-key-change-this
EOF
    echo "✅ .env 파일 생성 완료"
else
    echo "✅ .env 파일이 이미 존재합니다."
fi

echo ""
echo "🔧 설치 완료!"
echo ""
echo "📋 다음 단계:"
echo "1. .env 파일에서 DB_PASSWORD 수정:"
echo "   nano .env"
echo ""
echo "2. LogiFlow 시작:"
echo "   ./start.sh --init-db"
echo ""
echo "3. 웹 접속:"
echo "   http://192.168.0.109:7000"
echo ""
echo "4. 관리자 계정:"
echo "   ID: admin"
echo "   PW: admin123"
echo ""
echo "🛠️  관리 명령어:"
echo "   시작: ./start.sh"
echo "   종료: ./stop.sh"
echo "   재시작: ./stop.sh && ./start.sh"